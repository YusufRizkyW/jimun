import 'package:flutter/material.dart';
import 'antrian_screen.dart'; // pastikan file ini sudah ada

class DaftarScreen extends StatefulWidget {
  const DaftarScreen({super.key});

  @override
  State<DaftarScreen> createState() => _DaftarScreenState();
}

class _DaftarScreenState extends State<DaftarScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController namaController = TextEditingController();
  final TextEditingController nikController = TextEditingController();
  final TextEditingController tanggalLahirController = TextEditingController();
  String selectedImunisasi = 'Polio';

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => AntrianScreen(
            adaAntrian: true,
            nomorAntrian: 15, // nanti bisa diganti backend
            nama: namaController.text,
            nik: nikController.text,
            tanggalLahir: tanggalLahirController.text,
            jenisImunisasi: selectedImunisasi,
            tanggalPelayanan: "20 Januari 2025",
            lokasi: "Puskesmas Deket Lamongan",
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Formulir Pendaftaran")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: nikController,
                decoration: const InputDecoration(labelText: 'Nomor Induk Keluarga'),
                keyboardType: TextInputType.number,
                validator: (value) => value!.isEmpty ? 'Harus diisi' : null,
              ),
              TextFormField(
                controller: namaController,
                decoration: const InputDecoration(labelText: 'Nama lengkap anak'),
                validator: (value) => value!.isEmpty ? 'Harus diisi' : null,
              ),
              TextFormField(
                controller: tanggalLahirController,
                decoration: const InputDecoration(labelText: 'Tanggal Lahir (DD-MM-YYYY)'),
                validator: (value) => value!.isEmpty ? 'Harus diisi' : null,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: selectedImunisasi,
                items: ['Polio', 'Campak', 'Hepatitis'].map((e) {
                  return DropdownMenuItem(value: e, child: Text(e));
                }).toList(),
                onChanged: (value) => setState(() => selectedImunisasi = value!),
                decoration: const InputDecoration(labelText: 'Jenis Imunisasi'),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _submitForm,
                child: const Text("Daftar Sekarang"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
